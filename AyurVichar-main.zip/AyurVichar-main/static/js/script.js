console.log("Welcome Solve-Ease");
